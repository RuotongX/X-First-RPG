package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import start.Map;

class MoveUpTest extends Map{

	@Test
	void test() {
		MoveUpTest mut = new MoveUpTest();
		mut.setFloor(0);
		mut.getP().setRow(7);
		mut.moveup(0);
		int output = mut.getP().getRow();
		assertEquals(6,output);
	}

}
