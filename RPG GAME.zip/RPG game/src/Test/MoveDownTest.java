package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import start.Map;

class MoveDownTest extends Map{

	@Test
	void test() {
		MoveDownTest mdt = new MoveDownTest();
		mdt.setFloor(0);
		mdt.getP().setRow(2);
		mdt.movedown(0);;
		int output = mdt.getP().getRow();
		assertEquals(3,output);
	}

}
