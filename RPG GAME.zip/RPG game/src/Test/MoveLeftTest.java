package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import start.Map;

class MoveLeftTest extends Map{

	@Test
	void test() {
		MoveLeftTest mlt = new MoveLeftTest();
		mlt.setFloor(0);
		mlt.getP().setColumn(5);
		mlt.moveleft(0);
		int output = mlt.getP().getColumn();
		assertEquals(4,output);
	}

}
