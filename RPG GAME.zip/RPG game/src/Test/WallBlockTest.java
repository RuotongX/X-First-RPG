package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import start.Map;

class WallBlockTest extends Map{

	@Test
	void test() {
		WallBlockTest wbt = new WallBlockTest();
		wbt.setFloor(0);
		wbt.getP().setColumn(1);
		wbt.moveleft(0);
		int output = wbt.getP().getColumn();
		assertEquals(1,output);
		
	}

}
