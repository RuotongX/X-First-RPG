package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import start.Map;

class MoveRightTest extends Map{

	@Test
	void test() {
		MoveRightTest mrt = new MoveRightTest();
		mrt.setFloor(0);
		mrt.getP().setColumn(5);
		mrt.moveright(0);
		int output = mrt.getP().getColumn();
		assertEquals(6,output);
	}

}
