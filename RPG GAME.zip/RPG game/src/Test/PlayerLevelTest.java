package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import start.Map;

class PlayerLevelTest extends Map{

	@Test
	void test() {
		PlayerLevelTest plt = new PlayerLevelTest();
		plt.getP().setLevel(9);
		int output = plt.getP().getLevel();
		assertEquals(9,output);
	}

}
