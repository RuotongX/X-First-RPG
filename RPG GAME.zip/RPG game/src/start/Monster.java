package start;
/**
 * This class just show the monster has the same attributes as player. And it used the extends to implement.
 * @author RuotongXu QiChangZhou
 *
 */
public class Monster extends Player{
}
